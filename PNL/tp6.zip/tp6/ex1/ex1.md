# Question 1
voir le code suffixé .q1

# Question 2
voir le code
