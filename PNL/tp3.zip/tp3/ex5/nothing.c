#include<stdio.h>
#include<signal.h>

#include"func.h"

void func(void)
{
		printf("Nothing To Do !!!\n");
}
